# User manual 

Each class can be run individually, but the most useful classes are the
federator_splits.py and federator_mapper.py, as these run the federators
for both DASD and SADD methods.

Most of the important methods are commented, or are naturally intuitive
